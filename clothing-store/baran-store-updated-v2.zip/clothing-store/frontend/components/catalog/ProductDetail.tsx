'use client';

import Image from 'next/image';
import Link from 'next/link';
import { ArrowLeft, Check, Loader2, Minus, Plus, ShieldCheck, Truck } from 'lucide-react';
import { useMemo, useState } from 'react';
import { toast } from 'sonner';
import { useQuery } from '@tanstack/react-query';
import { formatAmount } from '@/lib/product';
import { useLocale } from '@/lib/i18n';
import { useCart } from '@/lib/cart';
import { getCatalogProduct, getCatalogProducts } from '@/services/catalog.service';
import ProductCard from './ProductCard';

export default function ProductDetail({ slug }: { slug: string }) {
  const { locale, t } = useLocale();
  const { addItem } = useCart();
  const [selectedVariantId, setSelectedVariantId] = useState<number | null>(null);
  const [quantity, setQuantity] = useState(1);
  const { data: product, isLoading, isError } = useQuery({ queryKey: ['catalog-product', slug, locale], queryFn: () => getCatalogProduct(slug, locale), retry: 1 });
  const { data: relatedPage } = useQuery({ queryKey: ['catalog-related', locale], queryFn: () => getCatalogProducts({ locale, per_page: 10, sort: 'featured' }), enabled: Boolean(product), retry: 1 });

  const variants = product?.variants ?? [];
  const selectedVariant = variants.find((item) => item.id === selectedVariantId) ?? variants[0];
  const selectedAttributes = useMemo(() => selectedVariant?.attributes ?? [], [selectedVariant]);

  if (isLoading) return <div className="mx-auto flex min-h-[70vh] max-w-[1440px] items-center justify-center"><Loader2 className="animate-spin text-accent" size={30} /></div>;
  if (isError || !product) return <div className="mx-auto max-w-[1440px] px-5 py-24 text-center"><p className="text-xl font-bold">{locale === 'fa' ? 'محصول پیدا نشد.' : 'Product not found.'}</p><Link href="/shop" className="mt-6 inline-flex rounded-full bg-foreground px-5 py-3 text-sm font-bold text-background">{t.actions.back}</Link></div>;

  const sizeValues = selectedAttributes.filter((item) => item.slug === 'size');
  const colorValues = selectedAttributes.filter((item) => item.slug === 'color');
  const addToBag = () => { for (let index = 0; index < quantity; index += 1) addItem(product, { variantId: selectedVariant?.id, size: sizeValues[0]?.value ?? '', color: colorValues[0]?.value ?? '' }); toast.success(t.actions.added, { description: product.name }); };
  const stock = selectedVariant?.stock ?? product.stock;
  const related = relatedPage?.data.filter((item) => item.id !== product.id).slice(0, 3) ?? [];

  return <div className="mx-auto max-w-[1440px] px-5 py-8 md:px-10 md:py-14"><Link href="/shop" className="mb-8 inline-flex items-center gap-2 text-sm font-bold text-muted-foreground transition hover:text-accent"><ArrowLeft size={16} />{t.actions.back}</Link><div className="grid gap-10 lg:grid-cols-[1.08fr_.92fr] lg:gap-16"><div className="grid grid-cols-2 gap-3"><div className="relative col-span-2 aspect-[1.18] overflow-hidden rounded-[1.5rem] bg-[#e8e5dc] dark:bg-zinc-800"><Image src={product.image} alt={product.name} fill priority sizes="(max-width: 1024px) 100vw, 55vw" className="object-cover" /></div><div className="relative aspect-square overflow-hidden rounded-[1.2rem] bg-[#e8e5dc] dark:bg-zinc-800"><Image src={product.image} alt={product.name} fill sizes="30vw" className="object-cover" /></div><div className="flex aspect-square items-center justify-center rounded-[1.2rem] bg-[#252522] text-center text-white"><span className="text-xs font-bold uppercase tracking-[.25em] text-accent">BARAN<br />ESSENTIALS</span></div></div><div className="lg:pt-4"><div className="mb-4 flex items-center gap-2 text-xs font-bold uppercase tracking-[.18em] text-accent"><span>{product.category?.name}</span><span className="text-border">/</span><span>{product.sku}</span></div><h1 className="display-heading max-w-xl text-5xl font-black md:text-7xl">{product.name}</h1><div className="mt-6 flex items-center gap-4"><span className="text-2xl font-black text-accent ltr-number">{formatAmount(selectedVariant?.prices.toman ?? product.priceToman, selectedVariant?.prices.usd ?? product.priceUsd, locale)}</span>{product.compareToman && <span className="text-sm text-muted-foreground line-through ltr-number">{locale === 'fa' ? `${product.compareToman.toLocaleString('fa-IR')} تومان` : `$${product.compareUsd}`}</span>}<span className="text-sm text-amber-500">★ {product.rating || '—'} <span className="text-muted-foreground">({product.reviews || 0})</span></span></div><p className="mt-7 max-w-xl text-base leading-8 text-muted-foreground">{product.description}</p>{variants.length > 0 && <div className="my-8 border-y border-border py-6"><div className="mb-5 text-sm font-bold">{locale === 'fa' ? 'انتخاب مدل' : 'Choose your variant'}</div><div className="flex flex-wrap gap-2">{variants.map((variant) => <button key={variant.id} onClick={() => setSelectedVariantId(variant.id)} className={`rounded-full border px-4 py-2.5 text-sm font-bold transition ${selectedVariant?.id === variant.id ? 'border-foreground bg-foreground text-background' : 'border-border hover:border-foreground'}`}>{variant.attributes.map((attribute) => attribute.value).filter(Boolean).join(' / ') || variant.sku}</button>)}</div></div>}<div className="flex gap-3"><div className="flex items-center rounded-full border border-border"><button onClick={() => setQuantity((value) => Math.max(1, value - 1))} className="p-3" aria-label="Decrease"><Minus size={16} /></button><span className="w-8 text-center text-sm font-bold">{quantity}</span><button onClick={() => setQuantity((value) => Math.min(stock, value + 1))} className="p-3" aria-label="Increase"><Plus size={16} /></button></div><button onClick={addToBag} disabled={stock < 1} className="flex flex-1 items-center justify-center gap-2 rounded-full bg-foreground px-6 py-3.5 text-sm font-bold text-background transition hover:bg-accent hover:text-white disabled:cursor-not-allowed disabled:opacity-50">{stock > 0 ? t.actions.add : t.product.unavailable}<ArrowLeft size={16} /></button></div><div className="mt-8 grid gap-4 border-t border-border pt-6 text-sm"><div className="flex items-center gap-3"><Truck size={18} className="text-accent" /><span>{t.product.shipping}</span></div><div className="flex items-center gap-3"><ShieldCheck size={18} className="text-accent" /><span>{t.product.returns}</span></div><div className="flex items-center gap-3"><Check size={18} className="text-accent" /><span>{stock} {t.product.stock}</span></div></div></div></div><section className="mt-24 border-t border-border pt-12"><h2 className="mb-8 text-3xl font-black">{t.product.related}</h2><div className="grid grid-cols-2 gap-4 md:grid-cols-3">{related.map((item) => <ProductCard key={item.id} product={item} />)}</div></section></div>;
}
