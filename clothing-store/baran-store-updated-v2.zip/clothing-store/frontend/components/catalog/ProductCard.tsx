'use client';
/* eslint-disable @typescript-eslint/no-explicit-any */

import Image from 'next/image';
import Link from 'next/link';
import { Heart, Loader2, Plus } from 'lucide-react';
import { toast } from 'sonner';
import { useMutation } from '@tanstack/react-query';
import type { Product } from '@/lib/product';
import { formatPrice } from '@/lib/product';
import { useLocale } from '@/lib/i18n';
import { useCart } from '@/lib/cart';
import { useCurrentUser } from '@/hooks/useAuth';
import { addWishlist } from '@/services/account.service';
import { useRouter } from 'next/navigation';

export default function ProductCard({ product, priority = false }: { product: Product; priority?: boolean }) {
  const { locale, t } = useLocale();
  const { addItem } = useCart();
  const { data: user } = useCurrentUser();
  const router = useRouter();
  const wishlist = useMutation({ mutationFn: () => addWishlist(product.id), onSuccess: (result) => toast.success(result.message), onError: (error: any) => toast.error(error.response?.data?.message ?? (locale === 'fa' ? 'ابتدا وارد حساب شو.' : 'Please sign in first.')) });

  const handleAdd = () => {
    addItem(product);
    toast.success(t.actions.added, { description: product.name });
  };

  return (
    <article className="group min-w-0">
      <div className="relative mb-4 aspect-[4/5] overflow-hidden rounded-[1.6rem] bg-[#e8e5dc] dark:bg-zinc-800">
        <Link href={`/product/${product.slug}`} aria-label={product.name} className="absolute inset-0 z-[1]">
          <Image src={product.image} alt={product.name} fill priority={priority} sizes="(max-width: 768px) 50vw, 25vw" className="object-cover transition duration-700 group-hover:scale-105" />
        </Link>
        <div className="hero-gradient pointer-events-none absolute inset-0 z-[2] opacity-40 transition duration-500 group-hover:opacity-70" />
        <div className="absolute left-4 right-4 top-4 z-[3] flex items-start justify-between">
          <div className="flex gap-2">
            {product.isNew && <span className="rounded-full bg-white/90 px-3 py-1 text-[11px] font-bold text-black backdrop-blur dark:bg-black/70 dark:text-white">{locale === 'fa' ? 'جدید' : 'New'}</span>}
            {product.compareToman && <span className="rounded-full bg-accent px-3 py-1 text-[11px] font-bold text-white">{locale === 'fa' ? 'پیشنهاد ویژه' : 'Sale'}</span>}
          </div>
          <button aria-label={locale === 'fa' ? 'افزودن به علاقه‌مندی‌ها' : 'Add to wishlist'} onClick={(event) => { event.preventDefault(); event.stopPropagation(); if (!user) { router.push('/login'); return; } wishlist.mutate(); }} disabled={wishlist.isPending} className="rounded-full bg-white/90 p-2.5 text-black backdrop-blur transition hover:bg-black hover:text-white disabled:opacity-70 dark:bg-black/60 dark:text-white dark:hover:bg-white dark:hover:text-black">
            {wishlist.isPending ? <Loader2 size={17} className="animate-spin" /> : <Heart size={17} strokeWidth={1.8} />}
          </button>
        </div>
        <button onClick={handleAdd} disabled={product.stock < 1} className="absolute bottom-4 left-4 right-4 z-[3] flex translate-y-2 items-center justify-center gap-2 rounded-full bg-white/95 py-3 text-sm font-bold text-black opacity-0 backdrop-blur transition duration-300 hover:bg-accent hover:text-white disabled:cursor-not-allowed disabled:opacity-60 group-hover:translate-y-0 group-hover:opacity-100 dark:bg-black/90 dark:text-white">
          <Plus size={16} /> {product.stock > 0 ? t.actions.add : t.product.unavailable}
        </button>
      </div>
      <div className="flex items-start justify-between gap-3 px-1">
        <div className="min-w-0">
          <Link href={`/product/${product.slug}`} className="block truncate text-base font-bold transition hover:text-accent">{product.name}</Link>
          <p className="mt-1 text-xs text-muted-foreground">{product.category?.name}</p>
          <p className="mt-2 font-bold text-accent ltr-number">{formatPrice(product, locale)}</p>
        </div>
        <div className="flex shrink-0 items-center gap-1 pt-1 text-xs text-muted-foreground"><span className="text-amber-500">★</span>{product.rating || '—'}</div>
      </div>
    </article>
  );
}
