'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { useInfiniteQuery, useQuery } from '@tanstack/react-query';
import { Loader2, Search, SlidersHorizontal, X } from 'lucide-react';
import { useSearchParams } from 'next/navigation';
import { useLocale } from '@/lib/i18n';
import { getCatalogFilters, getCatalogProducts, getCategories } from '@/services/catalog.service';
import ProductCard from './ProductCard';

export default function ShopView({ initialGender }: { initialGender?: 'men' | 'women' }) {
  const { locale, t } = useLocale();
  const searchParams = useSearchParams();
  const initialCategory = searchParams.get('category') ?? '';
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'new' | 'sale'>('all');
  const [sort, setSort] = useState('featured');
  const [category, setCategory] = useState(initialCategory);
  const [selectedFilters, setSelectedFilters] = useState<Record<string, string[]>>({});
  const [filtersOpen, setFiltersOpen] = useState(false);
  const loadMoreRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const timer = window.setTimeout(() => setSearch(searchInput.trim()), 350);
    return () => window.clearTimeout(timer);
  }, [searchInput]);

  const { data: categories = [], isLoading: categoriesLoading } = useQuery({ queryKey: ['catalog-categories', locale], queryFn: () => getCategories(locale), retry: 1 });
  const { data: filters = [] } = useQuery({ queryKey: ['catalog-filters', locale], queryFn: () => getCatalogFilters(locale), retry: 1 });
  const query = useInfiniteQuery({
    queryKey: ['catalog-products', locale, category, initialGender, activeTab, sort, search, selectedFilters],
    queryFn: ({ pageParam }) => getCatalogProducts({
      locale,
      page: pageParam,
      per_page: 10,
      category: category || undefined,
      gender: initialGender,
      search: search || undefined,
      featured: undefined,
      new: activeTab === 'new' ? true : undefined,
      sale: activeTab === 'sale' ? true : undefined,
      sort,
      size: selectedFilters.size?.join(',') || undefined,
      color: selectedFilters.color?.join(',') || undefined,
      material: selectedFilters.material?.join(',') || undefined,
    }),
    initialPageParam: 1,
    getNextPageParam: (lastPage) => lastPage.meta.current_page < lastPage.meta.last_page ? lastPage.meta.current_page + 1 : undefined,
    retry: 1,
  });

  const { data: queryData, hasNextPage, isFetchingNextPage, fetchNextPage } = query;
  useEffect(() => {
    const target = loadMoreRef.current;
    if (!target || !hasNextPage) return;
    const observer = new IntersectionObserver((entries) => {
      if (entries[0]?.isIntersecting && !isFetchingNextPage) fetchNextPage();
    }, { rootMargin: '500px' });
    observer.observe(target);
    return () => observer.disconnect();
  }, [fetchNextPage, hasNextPage, isFetchingNextPage]);

  const products = useMemo(() => queryData?.pages.flatMap((page) => page.data) ?? [], [queryData]);
  const heading = initialGender === 'men' ? t.nav.men : initialGender === 'women' ? t.nav.women : t.shop.title;
  const activeFilterCount = Object.values(selectedFilters).flat().length + (category ? 1 : 0);

  const toggleFilter = (filterSlug: string, valueSlug: string) => {
    setSelectedFilters((current) => {
      const values = current[filterSlug] ?? [];
      return { ...current, [filterSlug]: values.includes(valueSlug) ? values.filter((value) => value !== valueSlug) : [...values, valueSlug] };
    });
  };

  const resetFilters = () => { setCategory(''); setSelectedFilters({}); setSearchInput(''); setSearch(''); setActiveTab('all'); };

  return (
    <div className="mx-auto max-w-[1440px] px-5 py-12 md:px-10 md:py-20">
      <div className="mb-12 flex flex-col justify-between gap-7 border-b border-border pb-10 md:flex-row md:items-end"><div><p className="mb-3 text-xs font-bold uppercase tracking-[.2em] text-accent">BARAN / COLLECTION</p><h1 className="display-heading text-6xl font-black md:text-8xl">{heading}</h1><p className="mt-5 text-sm text-muted-foreground">{t.shop.subtitle}</p></div><div className="rounded-full border border-border px-4 py-2 text-sm text-muted-foreground">{queryData?.pages[0]?.meta.total ?? '—'} {locale === 'fa' ? 'محصول' : 'pieces'}</div></div>
      <div className="mb-6 flex flex-col gap-4 rounded-[1.5rem] border border-border bg-card p-4 md:p-5"><div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between"><div className="flex gap-2 overflow-x-auto no-scrollbar"><button onClick={() => setActiveTab('all')} className={`shrink-0 rounded-full px-5 py-2.5 text-sm font-bold transition ${activeTab === 'all' ? 'bg-foreground text-background' : 'border border-border text-muted-foreground hover:text-foreground'}`}>{t.shop.all}</button><button onClick={() => setActiveTab('new')} className={`shrink-0 rounded-full px-5 py-2.5 text-sm font-bold transition ${activeTab === 'new' ? 'bg-foreground text-background' : 'border border-border text-muted-foreground hover:text-foreground'}`}>{t.shop.new}</button><button onClick={() => setActiveTab('sale')} className={`shrink-0 rounded-full px-5 py-2.5 text-sm font-bold transition ${activeTab === 'sale' ? 'bg-foreground text-background' : 'border border-border text-muted-foreground hover:text-foreground'}`}>{t.shop.sale}</button></div><div className="flex gap-2"><label className="flex min-w-0 flex-1 items-center gap-2 rounded-full border border-border bg-background px-4 py-2.5 lg:w-72 lg:flex-none"><Search size={17} className="shrink-0 text-muted-foreground" /><input value={searchInput} onChange={(event) => setSearchInput(event.target.value)} placeholder={t.shop.search} className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground" />{searchInput && <button onClick={() => setSearchInput('')} aria-label="Clear"><X size={15} /></button>}</label><select value={sort} onChange={(event) => setSort(event.target.value)} className="hidden rounded-full border border-border bg-background px-4 text-sm outline-none md:block"><option value="featured">{t.shop.featured}</option><option value="newest">{t.shop.newest}</option><option value="price_asc">{t.shop.lowToHigh}</option><option value="price_desc">{t.shop.highToLow}</option></select><button onClick={() => setFiltersOpen((open) => !open)} className="flex items-center gap-2 rounded-full border border-border px-4 py-2.5 text-sm font-bold md:hidden"><SlidersHorizontal size={17} />{locale === 'fa' ? 'فیلترها' : 'Filters'}{activeFilterCount > 0 && <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-accent px-1 text-[11px] text-white">{activeFilterCount}</span>}</button></div></div><div className="flex flex-wrap gap-2">{categoriesLoading ? <span className="text-xs text-muted-foreground">{locale === 'fa' ? 'در حال دریافت دسته‌بندی‌ها...' : 'Loading categories...'}</span> : <><button onClick={() => setCategory('')} className={`rounded-full px-3.5 py-2 text-xs font-bold ${!category ? 'bg-accent text-white' : 'border border-border text-muted-foreground'}`}>{t.shop.all}</button>{categories.map((item) => <button key={item.slug} onClick={() => setCategory(item.slug)} className={`rounded-full px-3.5 py-2 text-xs font-bold ${category === item.slug ? 'bg-accent text-white' : 'border border-border text-muted-foreground'}`}>{item.name}</button>)}</>}</div></div>
      <div className={`${filtersOpen ? 'block' : 'hidden'} mb-8 rounded-[1.5rem] border border-border bg-card p-5 md:block`}><div className="mb-5 flex items-center justify-between"><div><h2 className="font-black">{locale === 'fa' ? 'فیلترهای دقیق' : 'Refine your search'}</h2><p className="mt-1 text-xs text-muted-foreground">{locale === 'fa' ? 'نتایج را دقیقاً مطابق استایل خودت پیدا کن.' : 'Find the exact fit for your style.'}</p></div><button onClick={resetFilters} className="text-xs font-bold text-accent">{locale === 'fa' ? 'حذف همه فیلترها' : 'Clear all'}</button></div><div className="grid gap-6 md:grid-cols-3">{filters.map((filter) => <div key={filter.slug}><h3 className="mb-3 text-sm font-bold">{filter.name}</h3><div className="flex flex-wrap gap-2">{filter.values.map((value) => { const active = selectedFilters[filter.slug]?.includes(value.slug); return <button key={value.slug} onClick={() => toggleFilter(filter.slug, value.slug)} className={`flex items-center gap-2 rounded-full border px-3 py-2 text-xs transition ${active ? 'border-accent bg-accent text-white' : 'border-border text-muted-foreground hover:border-foreground hover:text-foreground'}`}>{filter.type === 'color' && <span className="h-3 w-3 rounded-full border border-black/10" style={{ backgroundColor: value.color ?? '#aaa' }} />}{value.name}</button>; })}</div></div>)}</div></div>
      {query.isError ? <div className="flex min-h-80 flex-col items-center justify-center rounded-[1.5rem] border border-dashed border-red-300 text-center"><p className="text-xl font-bold">{locale === 'fa' ? 'ارتباط با فروشگاه برقرار نشد.' : 'Could not connect to the store.'}</p><p className="mt-2 text-sm text-muted-foreground">{locale === 'fa' ? 'آدرس API و اجرای Laravel را بررسی کن.' : 'Check the API URL and make sure Laravel is running.'}</p><button onClick={() => query.refetch()} className="mt-5 rounded-full bg-foreground px-5 py-2.5 text-sm font-bold text-background">{locale === 'fa' ? 'تلاش دوباره' : 'Try again'}</button></div> : products.length ? <><div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3 lg:grid-cols-4 md:gap-x-6 md:gap-y-14">{products.map((product, index) => <ProductCard key={`${product.id}-${index}`} product={product} priority={index < 2} />)}</div><div ref={loadMoreRef} className="flex min-h-24 items-center justify-center">{isFetchingNextPage && <Loader2 className="animate-spin text-accent" size={25} />}{!hasNextPage && !query.isLoading && <span className="text-xs text-muted-foreground">{locale === 'fa' ? 'به انتهای لیست رسیدی.' : 'You reached the end.'}</span>}</div></> : query.isLoading ? <div className="grid grid-cols-2 gap-4 md:grid-cols-4">{Array.from({ length: 8 }).map((_, index) => <div key={index} className="animate-pulse"><div className="aspect-[4/5] rounded-[1.5rem] bg-border/50" /><div className="mt-4 h-4 w-2/3 rounded bg-border/50" /><div className="mt-2 h-3 w-1/3 rounded bg-border/50" /></div>)}</div> : <div className="flex min-h-80 flex-col items-center justify-center rounded-[1.5rem] border border-dashed border-border text-center"><p className="text-2xl font-bold">{t.shop.empty}</p><button onClick={resetFilters} className="mt-5 rounded-full bg-foreground px-5 py-2.5 text-sm font-bold text-background">{locale === 'fa' ? 'پاک کردن فیلترها' : 'Clear filters'}</button></div>}
    </div>
  );
}
