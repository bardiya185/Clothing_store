'use client';
/* eslint-disable react-hooks/set-state-in-effect */

import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import type { Product } from './product';

type CartItem = { product: Product; quantity: number; variantId: number; size: string; color: string };
type CartContextValue = {
  items: CartItem[];
  count: number;
  addItem: (product: Product, options?: { variantId?: number; size?: string; color?: string }) => void;
  removeItem: (productId: number, variantId: number) => void;
  updateQuantity: (productId: number, variantId: number, quantity: number) => void;
  clear: () => void;
};

const CartContext = createContext<CartContextValue | null>(null);

function defaultOptions(product: Product) {
  const variant = product.variants?.[0];
  const size = variant?.attributes.find((item) => item.slug === 'size')?.value ?? '';
  const color = variant?.attributes.find((item) => item.slug === 'color')?.value ?? '';
  return { variantId: variant?.id ?? 0, size, color };
}

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);

  useEffect(() => {
    const saved = window.localStorage.getItem('baran-cart');
    if (!saved) return;
    try {
      const parsed = JSON.parse(saved) as CartItem[];
      if (Array.isArray(parsed) && parsed.every((item) => item.product?.slug && item.product?.priceToman !== undefined)) setItems(parsed);
      else window.localStorage.removeItem('baran-cart');
    } catch {
      window.localStorage.removeItem('baran-cart');
    }
  }, []);

  useEffect(() => {
    window.localStorage.setItem('baran-cart', JSON.stringify(items));
  }, [items]);

  const value = useMemo<CartContextValue>(() => ({
    items,
    count: items.reduce((total, item) => total + item.quantity, 0),
    addItem: (product, options = {}) => {
      const defaults = defaultOptions(product);
      const variantId = options.variantId ?? defaults.variantId;
      const size = options.size ?? defaults.size;
      const color = options.color ?? defaults.color;
      setItems((current) => {
        const existing = current.find((item) => item.product.id === product.id && item.variantId === variantId);
        if (existing) return current.map((item) => item === existing ? { ...item, quantity: Math.min(item.quantity + 1, Math.max(product.stock, 1)) } : item);
        return [...current, { product, quantity: 1, variantId, size, color }];
      });
    },
    removeItem: (productId, variantId) => setItems((current) => current.filter((item) => !(item.product.id === productId && item.variantId === variantId))),
    updateQuantity: (productId, variantId, quantity) => setItems((current) => current.map((item) => item.product.id === productId && item.variantId === variantId ? { ...item, quantity: Math.max(1, Math.min(quantity, Math.max(item.product.stock, 1))) } : item)),
    clear: () => setItems([]),
  }), [items]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) throw new Error('useCart must be used inside CartProvider');
  return context;
}
