<?php

use App\Http\Controllers\Api\AccountController;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\CatalogController;
use Illuminate\Support\Facades\Route;

// روت‌های آزاد (بدون نیاز به توکن)
Route::prefix('auth')->group(function () {
    Route::post('/send-otp', [AuthController::class, 'sendOtp']);
    Route::post('/verify-otp', [AuthController::class, 'verifyOtp']);
    Route::post('/refresh', [AuthController::class, 'refresh']);
});

// کاتالوگ عمومی فروشگاه؛ زبان با ?locale=fa|en یا هدر X-Locale انتخاب می‌شود.
Route::prefix('catalog')->group(function () {
    Route::get('/products', [CatalogController::class, 'index']);
    Route::get('/products/{slug}', [CatalogController::class, 'show']);
    Route::get('/categories', [CatalogController::class, 'categories']);
    Route::get('/filters', [CatalogController::class, 'filters']);
});

// روت‌های محافظت‌شده (نیاز به اکسس توکن دارن)
Route::middleware('auth:sanctum')->prefix('auth')->group(function () {
    Route::get('/me', [AuthController::class, 'me']);
    Route::post('/logout', [AuthController::class, 'logout']);
});

Route::middleware('auth:sanctum')->prefix('account')->group(function () {
    Route::patch('/profile', [AccountController::class, 'updateProfile']);
    Route::get('/wishlist', [AccountController::class, 'wishlist']);
    Route::post('/wishlist/{product}', [AccountController::class, 'addToWishlist']);
    Route::delete('/wishlist/{product}', [AccountController::class, 'removeFromWishlist']);
    Route::get('/orders', [AccountController::class, 'orders']);
});
