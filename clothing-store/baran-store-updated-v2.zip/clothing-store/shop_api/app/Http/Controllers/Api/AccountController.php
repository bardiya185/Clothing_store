<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\Account\UpdateProfileRequest;
use App\Http\Resources\ProductResource;
use App\Http\Resources\UserResource;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AccountController extends Controller
{
    public function updateProfile(UpdateProfileRequest $request): JsonResponse
    {
        /** @var User $user */
        $user = $request->user();
        $user->update($request->validated());

        return response()->json([
            'status' => 'success',
            'message' => __('account.profile_updated'),
            'data' => new UserResource($user->refresh()),
        ]);
    }

    public function wishlist(Request $request): JsonResponse
    {
        $products = $request->user()->wishlists()
            ->with(['product.translations', 'product.category.translations', 'product.images.translations', 'product.variants'])
            ->latest()
            ->get()
            ->pluck('product')
            ->filter()
            ->values();

        return response()->json([
            'status' => 'success',
            'data' => ProductResource::collection($products),
        ]);
    }

    public function addToWishlist(Request $request, Product $product): JsonResponse
    {
        $request->user()->wishlists()->firstOrCreate(['product_id' => $product->id]);

        return response()->json([
            'status' => 'success',
            'message' => __('account.wishlist_added'),
        ], 201);
    }

    public function removeFromWishlist(Request $request, Product $product): JsonResponse
    {
        $request->user()->wishlists()->where('product_id', $product->id)->delete();

        return response()->json([
            'status' => 'success',
            'message' => __('account.wishlist_removed'),
        ]);
    }

    public function orders(Request $request): JsonResponse
    {
        $orders = Order::query()
            ->where('user_id', $request->user()->id)
            ->with('items')
            ->latest()
            ->paginate(10);

        return response()->json([
            'status' => 'success',
            'data' => $orders->through(function (Order $order) {
                return [
                    'id' => $order->id,
                    'number' => $order->number,
                    'status' => $order->status,
                    'payment_status' => $order->payment_status,
                    'currency' => $order->currency_code,
                    'total_toman' => (int) $order->total_toman,
                    'total_usd' => (float) $order->total_usd,
                    'items_count' => $order->items->sum('quantity'),
                    'created_at' => $order->created_at?->toIso8601String(),
                ];
            }),
        ]);
    }
}
