<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\ProductResource;
use App\Models\Attribute;
use App\Models\Category;
use App\Models\Product;
use App\Support\LocaleManager;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CatalogController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $locale = LocaleManager::resolve($request);
        $query = Product::query()
            ->where('status', 'published')
            ->withCount(['reviews' => fn ($reviews) => $reviews->where('status', 'approved')])
            ->withAvg(['reviews' => fn ($reviews) => $reviews->where('status', 'approved')], 'rating')
            ->with([
                'translations',
                'category.translations',
                'images.translations',
                'variants' => fn ($query) => $query->where('is_active', true),
            ]);

        if ($request->filled('category')) {
            $query->whereHas('category', fn ($category) => $category->where('slug', $request->string('category')));
        }

        if ($request->filled('gender') && in_array($request->string('gender')->toString(), ['men', 'women', 'unisex'], true)) {
            $query->whereIn('gender', [$request->string('gender')->toString(), 'unisex']);
        }

        if ($request->boolean('featured')) {
            $query->where('is_featured', true);
        }

        if ($request->boolean('new')) {
            $query->where('is_new', true);
        }

        if ($request->boolean('sale')) {
            $query->whereHas('variants', fn ($variants) => $variants
                ->where('is_active', true)
                ->where(function ($prices) {
                    $prices->whereNotNull('compare_at_toman')->orWhereNotNull('compare_at_usd');
                }));
        }

        foreach (['size', 'color', 'material'] as $attributeSlug) {
            if (!$request->filled($attributeSlug)) {
                continue;
            }

            $values = collect(explode(',', $request->string($attributeSlug)->toString()))
                ->map(fn ($value) => trim($value))
                ->filter()
                ->values();

            if ($values->isEmpty()) {
                continue;
            }

            $query->whereHas('variants', function ($variants) use ($attributeSlug, $values) {
                $variants->where('is_active', true)
                    ->whereHas('attributeValues', function ($attributeValues) use ($attributeSlug, $values) {
                        $attributeValues->whereIn('slug', $values->all())
                            ->whereHas('attribute', fn ($attribute) => $attribute->where('slug', $attributeSlug));
                    });
            });
        }

        if ($request->filled('search')) {
            $search = $request->string('search')->toString();
            $query->whereHas('translations', function ($translations) use ($search, $locale) {
                $translations->where('locale_code', $locale)
                    ->where(function ($translation) use ($search) {
                        $translation->where('name', 'like', "%{$search}%")
                            ->orWhere('description', 'like', "%{$search}%");
                    });
            });
        }

        match ($request->string('sort', 'featured')->toString()) {
            'price_asc' => $query->orderByRaw('(select price_toman from product_variants where product_variants.product_id = products.id and product_variants.is_active = 1 order by is_default desc, id asc limit 1) asc'),
            'price_desc' => $query->orderByRaw('(select price_toman from product_variants where product_variants.product_id = products.id and product_variants.is_active = 1 order by is_default desc, id asc limit 1) desc'),
            'newest' => $query->latest(),
            default => $query->orderByDesc('is_featured')->orderByDesc('is_new')->orderBy('sort_order'),
        };

        $products = $query->paginate(min(max($request->integer('per_page', 10), 1), 10))->withQueryString();

        return response()->json([
            'status' => 'success',
            'data' => ProductResource::collection($products),
            'meta' => [
                'locale' => $locale,
                'currency' => LocaleManager::currencyFor($locale),
                'current_page' => $products->currentPage(),
                'last_page' => $products->lastPage(),
                'per_page' => $products->perPage(),
                'total' => $products->total(),
            ],
        ]);
    }

    public function show(Request $request, string $slug): JsonResponse
    {
        $product = Product::query()
            ->where('status', 'published')
            ->where('slug', $slug)
            ->withCount(['reviews' => fn ($reviews) => $reviews->where('status', 'approved')])
            ->withAvg(['reviews' => fn ($reviews) => $reviews->where('status', 'approved')], 'rating')
            ->with([
                'translations',
                'category.translations',
                'images.translations',
                'variants.attributeValues.translations',
                'variants.attributeValues.attribute.translations',
            ])
            ->first();

        if (!$product) {
            return response()->json([
                'status' => 'error',
                'message' => __('catalog.product_not_found'),
                'errors' => ['slug' => [__('catalog.product_not_found')]],
            ], 404);
        }

        $product->increment('views_count');

        return response()->json([
            'status' => 'success',
            'data' => new ProductResource($product),
            'meta' => [
                'locale' => LocaleManager::resolve($request),
                'currency' => LocaleManager::currencyFor(LocaleManager::resolve($request)),
            ],
        ]);
    }

    public function categories(Request $request): JsonResponse
    {
        $locale = LocaleManager::resolve($request);
        $categories = Category::query()
            ->where('is_active', true)
            ->with('translations')
            ->withCount(['products' => fn ($query) => $query->where('status', 'published')])
            ->orderBy('sort_order')
            ->get()
            ->map(function (Category $category) use ($locale) {
                $translation = $category->translations->firstWhere('locale_code', $locale)
                    ?? $category->translations->firstWhere('locale_code', LocaleManager::fallback($locale));

                return [
                    'slug' => $category->slug,
                    'name' => $translation?->name,
                    'description' => $translation?->description,
                    'image' => $category->image_path ? '/'.ltrim($category->image_path, '/') : null,
                    'products_count' => $category->products_count,
                ];
            });

        return response()->json([
            'status' => 'success',
            'data' => $categories,
            'meta' => ['locale' => $locale],
        ]);
    }

    public function filters(Request $request): JsonResponse
    {
        $locale = LocaleManager::resolve($request);
        $attributes = Attribute::query()
            ->where('is_filterable', true)
            ->with(['translations', 'values.translations'])
            ->orderBy('sort_order')
            ->get()
            ->map(function (Attribute $attribute) use ($locale) {
                $translation = $attribute->translations->firstWhere('locale_code', $locale)
                    ?? $attribute->translations->firstWhere('locale_code', LocaleManager::fallback($locale));

                return [
                    'slug' => $attribute->slug,
                    'name' => $translation?->name,
                    'type' => $attribute->type,
                    'values' => $attribute->values->map(function ($value) use ($locale) {
                        $translation = $value->translations->firstWhere('locale_code', $locale)
                            ?? $value->translations->firstWhere('locale_code', LocaleManager::fallback($locale));

                        return [
                            'slug' => $value->slug,
                            'name' => $translation?->name,
                            'color' => $value->color_hex,
                        ];
                    })->values(),
                ];
            });

        return response()->json([
            'status' => 'success',
            'data' => $attributes,
            'meta' => ['locale' => $locale],
        ]);
    }
}
