<?php

return [
    'profile_updated' => 'Your profile was updated successfully.',
    'name_invalid' => 'The name is invalid.',
    'email_invalid' => 'The email format is invalid.',
    'email_taken' => 'This email is already in use.',
    'wishlist_added' => 'Product added to your wishlist.',
    'wishlist_removed' => 'Product removed from your wishlist.',
];
