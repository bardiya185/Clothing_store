<?php

namespace Database\Seeders;

use App\Models\Attribute;
use App\Models\Category;
use App\Models\Product;
use App\Models\ProductImage;
use App\Models\ProductImageTranslation;
use App\Models\ProductTranslation;
use App\Models\ProductVariant;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    public function run(): void
    {
        $categories = Category::pluck('id', 'slug');
        $attributeIds = Attribute::with('values')->get()->mapWithKeys(fn ($attribute) => [$attribute->slug => $attribute->values->pluck('id', 'slug')]);
        $products = [
            ['slug' => 'essential-oversized-hoodie', 'sku' => 'BRN-HDY-001', 'category' => 'hoodies', 'gender' => 'unisex', 'image' => 'Images/p1.jpg', 'featured' => true, 'new' => true, 'fa' => ['name' => 'هودی اورسایز اسنشیال', 'short_description' => 'یک هودی سنگین و نرم برای روزهای خنک.', 'description' => 'طراحی اورسایز با پارچه دورس سه‌نخ، سرآستین کشباف و دوخت تمیز ایرانی.'], 'en' => ['name' => 'Essential Oversized Hoodie', 'short_description' => 'A heavyweight soft layer for cooler days.', 'description' => 'An oversized silhouette in premium three-thread fleece with ribbed cuffs and clean local craftsmanship.'], 'price_toman' => 1280000, 'price_usd' => 39, 'compare_toman' => 1490000, 'compare_usd' => 46, 'stock' => 18, 'values' => ['size' => 'm', 'color' => 'stone', 'material' => 'fleece']],
            ['slug' => 'daily-boxy-tee', 'sku' => 'BRN-TEE-002', 'category' => 't-shirts', 'gender' => 'unisex', 'image' => 'Images/p2.jpg', 'featured' => true, 'new' => false, 'fa' => ['name' => 'تیشرت باکسی دیلی', 'short_description' => 'بیسیک روزانه با فرم آزاد و شخصیت خودش.', 'description' => 'تیشرت پنبه‌ای با یقه محکم، فرم باکسی و چاپ مینیمال باران.'], 'en' => ['name' => 'Daily Boxy Tee', 'short_description' => 'A relaxed everyday basic with its own attitude.', 'description' => 'A heavyweight cotton tee with a structured collar, boxy fit and minimal Baran mark.'], 'price_toman' => 590000, 'price_usd' => 19, 'compare_toman' => null, 'compare_usd' => null, 'stock' => 26, 'values' => ['size' => 'l', 'color' => 'black', 'material' => 'cotton']],
            ['slug' => 'relaxed-cargo-pants', 'sku' => 'BRN-PNT-003', 'category' => 'pants', 'gender' => 'men', 'image' => 'Images/p3.jpg', 'featured' => true, 'new' => true, 'fa' => ['name' => 'شلوار کارگو ریلکس', 'short_description' => 'جیب‌های کاربردی، فرم آزاد، حرکت بدون محدودیت.', 'description' => 'شلوار کارگو با کمر کشی، بند تنظیم و جیب‌های عمیق برای استایل هر روز.'], 'en' => ['name' => 'Relaxed Cargo Pants', 'short_description' => 'Utility pockets, relaxed shape, zero restriction.', 'description' => 'Relaxed cargo pants with an elastic waist, adjustable drawcord and deep everyday pockets.'], 'price_toman' => 1490000, 'price_usd' => 49, 'compare_toman' => 1690000, 'compare_usd' => 55, 'stock' => 14, 'values' => ['size' => 'm', 'color' => 'olive', 'material' => 'cotton']],
            ['slug' => 'soft-utility-overshirt', 'sku' => 'BRN-SHR-004', 'category' => 'hoodies', 'gender' => 'women', 'image' => 'Images/hero.jpg', 'featured' => false, 'new' => true, 'fa' => ['name' => 'اورشرت سافت یوتیلیتی', 'short_description' => 'یک لایه سبک برای کامل‌کردن هر استایل.', 'description' => 'اورشرت سبک با دوخت کاربردی و فرم آزاد، ساخته‌شده برای لایه‌پوشی.'], 'en' => ['name' => 'Soft Utility Overshirt', 'short_description' => 'The light layer that finishes every look.', 'description' => 'A relaxed lightweight overshirt with utility stitching, made for easy layering.'], 'price_toman' => 1190000, 'price_usd' => 38, 'compare_toman' => null, 'compare_usd' => null, 'stock' => 11, 'values' => ['size' => 's', 'color' => 'cream', 'material' => 'linen']],
            ['slug' => 'baran-statement-cap', 'sku' => 'BRN-CAP-005', 'category' => 'accessories', 'gender' => 'unisex', 'image' => 'Images/p2.jpg', 'featured' => false, 'new' => false, 'fa' => ['name' => 'کپ استیتمنت باران', 'short_description' => 'امضای آخر برای یک استایل کامل.', 'description' => 'کپ شش‌تکه با بند تنظیم و لوگوی گلدوزی‌شده باران.'], 'en' => ['name' => 'Baran Statement Cap', 'short_description' => 'The final signature for a complete look.', 'description' => 'A six-panel cap with an adjustable strap and embroidered Baran mark.'], 'price_toman' => 420000, 'price_usd' => 15, 'compare_toman' => null, 'compare_usd' => null, 'stock' => 35, 'values' => ['size' => 'm', 'color' => 'black', 'material' => 'cotton']],
            ['slug' => 'everyday-heavy-tee', 'sku' => 'BRN-TEE-006', 'category' => 't-shirts', 'gender' => 'women', 'image' => 'Images/p3.jpg', 'featured' => false, 'new' => true, 'fa' => ['name' => 'تیشرت سنگین روزمره', 'short_description' => 'سادگی‌ای که از دور هم دیده می‌شود.', 'description' => 'تیشرت سنگین با فرم relaxed و پارچه‌ای که بعد از شست‌وشو فرم خود را حفظ می‌کند.'], 'en' => ['name' => 'Everyday Heavy Tee', 'short_description' => 'The kind of simplicity you notice from across the room.', 'description' => 'A heavyweight relaxed tee that keeps its shape wash after wash.'], 'price_toman' => 690000, 'price_usd' => 22, 'compare_toman' => null, 'compare_usd' => null, 'stock' => 20, 'values' => ['size' => 's', 'color' => 'stone', 'material' => 'cotton']],
        ];

        foreach ($products as $sortOrder => $data) {
            $product = Product::updateOrCreate(['slug' => $data['slug']], [
                'category_id' => $categories[$data['category']], 'sku' => $data['sku'], 'gender' => $data['gender'], 'status' => 'published', 'is_featured' => $data['featured'], 'is_new' => $data['new'], 'sort_order' => $sortOrder,
            ]);
            foreach (['fa', 'en'] as $locale) ProductTranslation::updateOrCreate(['product_id' => $product->id, 'locale_code' => $locale], $data[$locale]);

            $variant = ProductVariant::updateOrCreate(['sku' => $data['sku'].'-DEFAULT'], [
                'product_id' => $product->id, 'price_toman' => $data['price_toman'], 'price_usd' => $data['price_usd'], 'compare_at_toman' => $data['compare_toman'], 'compare_at_usd' => $data['compare_usd'], 'stock' => $data['stock'], 'is_default' => true, 'is_active' => true,
            ]);
            $variant->attributeValues()->sync(array_map(fn ($attributeSlug, $valueSlug) => $attributeIds[$attributeSlug][$valueSlug], array_keys($data['values']), $data['values']));

            $image = ProductImage::updateOrCreate(['product_id' => $product->id, 'path' => $data['image']], ['variant_id' => $variant->id, 'is_primary' => true, 'sort_order' => 0, 'alt_text' => $data['en']['name']]);
            foreach (['fa', 'en'] as $locale) ProductImageTranslation::updateOrCreate(['product_image_id' => $image->id, 'locale_code' => $locale], ['alt_text' => $data[$locale]['name']]);
        }
    }
}
