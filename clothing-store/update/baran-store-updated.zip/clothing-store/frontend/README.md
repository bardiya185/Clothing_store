# Baran Store Frontend

A bilingual (Persian / English) storefront built with Next.js 16, React 19, TypeScript and Tailwind CSS v4.

## Features

- RTL Persian and LTR English modes with a language switcher
- Automatic display currency: تومان for Persian, USD for English
- Responsive hero, catalog, category, product detail, about and cart pages
- Local cart state persisted in the browser
- Product cards, filtering, search, sorting and light/dark mode
- Optional Laravel catalog integration with a static fallback for local previews

## Run locally

```bash
npm install
npm run dev
```

To connect to the Laravel API, create `.env.local`:

```env
NEXT_PUBLIC_API_URL=http://localhost:8000/api
```

If the variable is omitted, the UI uses the included seeded preview catalog. The Laravel API expects `?locale=fa` or `?locale=en` and returns prices in the matching currency.
