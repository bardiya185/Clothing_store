export type Locale = 'fa' | 'en';
export type Gender = 'men' | 'women' | 'unisex';

export type Product = {
  id: number;
  slug: string;
  sku: string;
  gender: Gender;
  category: { slug: string; fa: string; en: string };
  name: { fa: string; en: string };
  shortDescription: { fa: string; en: string };
  description: { fa: string; en: string };
  image: string;
  images?: string[];
  priceToman: number;
  priceUsd: number;
  compareToman?: number;
  compareUsd?: number;
  stock: number;
  rating: number;
  reviews: number;
  isNew?: boolean;
  isFeatured?: boolean;
  attributes: {
    size: string[];
    color: { slug: string; fa: string; en: string; hex: string }[];
    material: { fa: string; en: string };
  };
};

export const categories = [
  { slug: 'hoodies', fa: 'هودی و سویشرت', en: 'Hoodies & sweatshirts', image: '/Images/p1.jpg', count: 12 },
  { slug: 't-shirts', fa: 'تیشرت', en: 'T-shirts', image: '/Images/p2.jpg', count: 18 },
  { slug: 'pants', fa: 'شلوار', en: 'Pants', image: '/Images/p3.jpg', count: 9 },
  { slug: 'accessories', fa: 'اکسسوری', en: 'Accessories', image: '/Images/hero.jpg', count: 7 },
] as const;

export const products: Product[] = [
  {
    id: 1, slug: 'essential-oversized-hoodie', sku: 'BRN-HDY-001', gender: 'unisex', category: { slug: 'hoodies', fa: 'هودی و سویشرت', en: 'Hoodies & sweatshirts' },
    name: { fa: 'هودی اورسایز اسنشیال', en: 'Essential oversized hoodie' },
    shortDescription: { fa: 'یک هودی سنگین و نرم برای روزهای خنک.', en: 'A heavyweight soft layer for cooler days.' },
    description: { fa: 'طراحی اورسایز با پارچه دورس سه‌نخ، سرآستین کشباف و دوخت تمیز ایرانی.', en: 'An oversized silhouette in premium three-thread fleece with ribbed cuffs and clean local craftsmanship.' },
    image: '/Images/p1.jpg', priceToman: 1280000, priceUsd: 39, compareToman: 1490000, compareUsd: 46, stock: 18, rating: 4.8, reviews: 120, isNew: true, isFeatured: true,
    attributes: { size: ['S', 'M', 'L', 'XL'], color: [{ slug: 'stone', fa: 'طوسی سنگی', en: 'Stone', hex: '#9B9A96' }, { slug: 'black', fa: 'مشکی', en: 'Black', hex: '#171717' }, { slug: 'cream', fa: 'کرم', en: 'Cream', hex: '#E9E2D0' }], material: { fa: 'دورس سه‌نخ', en: 'Three-thread fleece' } },
  },
  {
    id: 2, slug: 'daily-boxy-tee', sku: 'BRN-TEE-002', gender: 'unisex', category: { slug: 't-shirts', fa: 'تیشرت', en: 'T-shirts' },
    name: { fa: 'تیشرت باکسی دیلی', en: 'Daily boxy tee' },
    shortDescription: { fa: 'بیسیک روزانه با فرم آزاد و شخصیت خودش.', en: 'A relaxed everyday basic with its own attitude.' },
    description: { fa: 'تیشرت پنبه‌ای با یقه محکم، فرم باکسی و چاپ مینیمال باران.', en: 'A heavyweight cotton tee with a structured collar, boxy fit and minimal Baran mark.' },
    image: '/Images/p2.jpg', priceToman: 590000, priceUsd: 19, stock: 26, rating: 4.7, reviews: 86, isFeatured: true,
    attributes: { size: ['S', 'M', 'L', 'XL'], color: [{ slug: 'black', fa: 'مشکی', en: 'Black', hex: '#171717' }, { slug: 'stone', fa: 'طوسی سنگی', en: 'Stone', hex: '#9B9A96' }], material: { fa: 'نخ پنبه', en: 'Cotton' } },
  },
  {
    id: 3, slug: 'relaxed-cargo-pants', sku: 'BRN-PNT-003', gender: 'men', category: { slug: 'pants', fa: 'شلوار', en: 'Pants' },
    name: { fa: 'شلوار کارگو ریلکس', en: 'Relaxed cargo pants' },
    shortDescription: { fa: 'جیب‌های کاربردی، فرم آزاد، حرکت بدون محدودیت.', en: 'Utility pockets, relaxed shape, zero restriction.' },
    description: { fa: 'شلوار کارگو با کمر کشی، بند تنظیم و جیب‌های عمیق برای استایل هر روز.', en: 'Relaxed cargo pants with an elastic waist, adjustable drawcord and deep everyday pockets.' },
    image: '/Images/p3.jpg', priceToman: 1490000, priceUsd: 49, compareToman: 1690000, compareUsd: 55, stock: 14, rating: 4.9, reviews: 64, isNew: true, isFeatured: true,
    attributes: { size: ['S', 'M', 'L', 'XL'], color: [{ slug: 'olive', fa: 'زیتونی', en: 'Olive', hex: '#626B4D' }, { slug: 'black', fa: 'مشکی', en: 'Black', hex: '#171717' }], material: { fa: 'نخ پنبه', en: 'Cotton' } },
  },
  {
    id: 4, slug: 'soft-utility-overshirt', sku: 'BRN-SHR-004', gender: 'women', category: { slug: 'hoodies', fa: 'هودی و سویشرت', en: 'Hoodies & sweatshirts' },
    name: { fa: 'اورشرت سافت یوتیلیتی', en: 'Soft utility overshirt' },
    shortDescription: { fa: 'یک لایه سبک برای کامل‌کردن هر استایل.', en: 'The light layer that finishes every look.' },
    description: { fa: 'اورشرت سبک با دوخت کاربردی و فرم آزاد، ساخته‌شده برای لایه‌پوشی.', en: 'A relaxed lightweight overshirt with utility stitching, made for easy layering.' },
    image: '/Images/hero.jpg', priceToman: 1190000, priceUsd: 38, stock: 11, rating: 4.6, reviews: 41, isNew: true,
    attributes: { size: ['S', 'M', 'L'], color: [{ slug: 'cream', fa: 'کرم', en: 'Cream', hex: '#E9E2D0' }, { slug: 'olive', fa: 'زیتونی', en: 'Olive', hex: '#626B4D' }], material: { fa: 'لینن', en: 'Linen' } },
  },
  {
    id: 5, slug: 'baran-statement-cap', sku: 'BRN-CAP-005', gender: 'unisex', category: { slug: 'accessories', fa: 'اکسسوری', en: 'Accessories' },
    name: { fa: 'کپ استیتمنت باران', en: 'Baran statement cap' },
    shortDescription: { fa: 'امضای آخر برای یک استایل کامل.', en: 'The final signature for a complete look.' },
    description: { fa: 'کپ شش‌تکه با بند تنظیم و لوگوی گلدوزی‌شده باران.', en: 'A six-panel cap with an adjustable strap and embroidered Baran mark.' },
    image: '/Images/p2.jpg', priceToman: 420000, priceUsd: 15, stock: 35, rating: 4.8, reviews: 29,
    attributes: { size: ['One size'], color: [{ slug: 'black', fa: 'مشکی', en: 'Black', hex: '#171717' }, { slug: 'cream', fa: 'کرم', en: 'Cream', hex: '#E9E2D0' }], material: { fa: 'نخ پنبه', en: 'Cotton' } },
  },
  {
    id: 6, slug: 'everyday-heavy-tee', sku: 'BRN-TEE-006', gender: 'women', category: { slug: 't-shirts', fa: 'تیشرت', en: 'T-shirts' },
    name: { fa: 'تیشرت سنگین روزمره', en: 'Everyday heavy tee' },
    shortDescription: { fa: 'سادگی‌ای که از دور هم دیده می‌شود.', en: 'The kind of simplicity you notice from across the room.' },
    description: { fa: 'تیشرت سنگین با فرم relaxed و پارچه‌ای که بعد از شست‌وشو فرم خود را حفظ می‌کند.', en: 'A heavyweight relaxed tee that keeps its shape wash after wash.' },
    image: '/Images/p3.jpg', priceToman: 690000, priceUsd: 22, stock: 20, rating: 4.7, reviews: 52, isNew: true,
    attributes: { size: ['S', 'M', 'L'], color: [{ slug: 'stone', fa: 'طوسی سنگی', en: 'Stone', hex: '#9B9A96' }, { slug: 'black', fa: 'مشکی', en: 'Black', hex: '#171717' }], material: { fa: 'نخ پنبه', en: 'Cotton' } },
  },
];

export function localized<T extends { fa: string; en: string }>(value: T, locale: Locale) {
  return value[locale];
}

export function formatPrice(product: Pick<Product, 'priceToman' | 'priceUsd'>, locale: Locale) {
  if (locale === 'fa') return `${new Intl.NumberFormat('fa-IR').format(product.priceToman)} تومان`;
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(product.priceUsd);
}

export function formatNumber(value: number, locale: Locale) {
  return new Intl.NumberFormat(locale === 'fa' ? 'fa-IR' : 'en-US').format(value);
}

export function getProduct(slug: string) {
  return products.find((product) => product.slug === slug);
}

export type ApiProduct = {
  id: number;
  slug: string;
  sku: string;
  gender: Gender;
  is_featured?: boolean;
  is_new?: boolean;
  category?: { slug: string; name: string } | null;
  name: string;
  short_description?: string;
  description?: string;
  prices?: { toman: number; usd: number; compare_at_toman?: number | null; compare_at_usd?: number | null } | null;
  stock?: number;
  images?: { url: string; alt?: string }[];
};

export function mapApiProduct(item: ApiProduct, locale: Locale): Product {
  const fallback = products.find((product) => product.slug === item.slug);
  const categoryName = item.category?.name ?? fallback?.category[locale] ?? '';
  return {
    id: item.id,
    slug: item.slug,
    sku: item.sku,
    gender: item.gender,
    category: { slug: item.category?.slug ?? fallback?.category.slug ?? 'collection', fa: locale === 'fa' ? categoryName : fallback?.category.fa ?? categoryName, en: locale === 'en' ? categoryName : fallback?.category.en ?? categoryName },
    name: { fa: locale === 'fa' ? item.name : fallback?.name.fa ?? item.name, en: locale === 'en' ? item.name : fallback?.name.en ?? item.name },
    shortDescription: { fa: locale === 'fa' ? item.short_description ?? '' : fallback?.shortDescription.fa ?? item.short_description ?? '', en: locale === 'en' ? item.short_description ?? '' : fallback?.shortDescription.en ?? item.short_description ?? '' },
    description: { fa: locale === 'fa' ? item.description ?? '' : fallback?.description.fa ?? item.description ?? '', en: locale === 'en' ? item.description ?? '' : fallback?.description.en ?? item.description ?? '' },
    image: item.images?.[0]?.url ?? fallback?.image ?? '/Images/hero.jpg',
    priceToman: item.prices?.toman ?? fallback?.priceToman ?? 0,
    priceUsd: item.prices?.usd ?? fallback?.priceUsd ?? 0,
    compareToman: item.prices?.compare_at_toman ?? fallback?.compareToman,
    compareUsd: item.prices?.compare_at_usd ?? fallback?.compareUsd,
    stock: item.stock ?? fallback?.stock ?? 0,
    rating: fallback?.rating ?? 4.8,
    reviews: fallback?.reviews ?? 0,
    isNew: item.is_new ?? fallback?.isNew,
    isFeatured: item.is_featured ?? fallback?.isFeatured,
    attributes: fallback?.attributes ?? { size: ['S', 'M', 'L', 'XL'], color: [{ slug: 'black', fa: 'مشکی', en: 'Black', hex: '#171717' }], material: { fa: 'نخ پنبه', en: 'Cotton' } },
  };
}
