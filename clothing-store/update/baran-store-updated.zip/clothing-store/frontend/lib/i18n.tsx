'use client';
/* eslint-disable react-hooks/set-state-in-effect */

import { createContext, useContext, useEffect, useMemo, useState } from 'react';

export type Locale = 'fa' | 'en';

const messages = {
  fa: {
    nav: { home: 'خانه', shop: 'فروشگاه', men: 'مردانه', women: 'زنانه', about: 'درباره ما' },
    actions: { shopNow: 'مشاهده کالکشن', explore: 'کشف کن', viewAll: 'مشاهده همه', add: 'افزودن به سبد', added: 'به سبد اضافه شد', details: 'جزئیات محصول', back: 'بازگشت به فروشگاه', checkout: 'ادامه ثبت سفارش', continue: 'ادامه خرید', remove: 'حذف', clear: 'خالی کردن سبد' },
    home: { eyebrow: 'دراپ جدید / پاییز ۱۴۰۵', titleA: 'ساده بپوش،', titleB: 'متفاوت دیده شو.', description: 'لباس‌هایی برای حرکت، ماندن و ساختن استایل خودت؛ طراحی‌شده در ایران، آماده برای هر جای دنیا.', pieces: 'قطعه محدود', models: 'مدل فعال', shipping: 'ارسال سریع', categories: 'دسته‌بندی‌ها', categoryHint: 'قطعه بعدی استایل تو اینجاست.', bestsellers: 'انتخاب تیم طراحی', featured: 'پرفروش‌ترین‌ها', featuredHint: 'چیزهایی که این هفته بیشتر دوستشان داشتید.', manifesto: 'لباس، قبل از هر چیز، باید شبیه زندگی تو باشد.', manifestoHint: 'باران از فرم‌های راحت، پارچه‌های واقعی و جزئیات کوچک ساخته می‌شود؛ برای اینکه خودت را ساده‌تر، دقیق‌تر و آزادتر نشان بدهی.', join: 'همراه باران باش', joinHint: 'برای خبرهای دراپ بعدی ایمیلت را ثبت کن.' },
    shop: { title: 'فروشگاه', subtitle: 'قطعاتی که قرار نیست شبیه همه باشند.', all: 'همه', new: 'جدیدها', sale: 'تخفیف‌دار', search: 'جست‌وجوی محصول...', sort: 'مرتب‌سازی', featured: 'منتخب باران', newest: 'جدیدترین', lowToHigh: 'ارزان‌ترین', highToLow: 'گران‌ترین', empty: 'محصولی با این فیلتر پیدا نشد.' },
    product: { available: 'موجود', unavailable: 'ناموجود', size: 'سایز', color: 'رنگ', material: 'جنس', description: 'درباره محصول', shipping: 'ارسال رایگان برای سفارش‌های بالای ۵۰۰ هزار تومان', returns: 'تعویض تا ۷ روز با خیال راحت', related: 'شاید این‌ها را هم دوست داشته باشی', reviews: 'دیدگاه', stock: 'عدد در انبار' },
    cart: { title: 'سبد خرید', empty: 'سبدت هنوز خالی است.', emptyHint: 'یک قطعه انتخاب کن و داستان استایلت را شروع کن.', summary: 'خلاصه سفارش', subtotal: 'جمع سبد', shipping: 'ارسال', free: 'رایگان', total: 'مبلغ نهایی', loginHint: 'برای ادامه، وارد حساب کاربری شو.' },
    footer: { tagline: 'استریت‌ویر ایرانی برای زندگی واقعی.', shop: 'فروشگاه', account: 'حساب کاربری', newsletter: 'خبرنامه', newsletterHint: 'از دراپ‌های تازه باخبر شو.', email: 'ایمیل شما', subscribe: 'عضویت', rights: 'تمامی حقوق برای باران محفوظ است.' },
    about: { eyebrow: 'داستان باران', title: 'کمتر، اما درست‌تر.', body: 'باران یک برند مستقل است برای آدم‌هایی که دنبال لباس‌های پر سر و صدا نیستند؛ دنبال لباسی هستند که با زندگی‌شان راه بیاید. هر قطعه با فرم راحت، پارچه انتخاب‌شده و جزئیاتی که لازم است ساخته می‌شود.', point1: 'طراحی‌شده در ایران', point2: 'پارچه‌های انتخاب‌شده', point3: 'تولید محدود و مسئولانه' },
  },
  en: {
    nav: { home: 'Home', shop: 'Shop', men: 'Men', women: 'Women', about: 'About' },
    actions: { shopNow: 'Explore collection', explore: 'Explore', viewAll: 'View all', add: 'Add to bag', added: 'Added to bag', details: 'Product details', back: 'Back to shop', checkout: 'Continue to checkout', continue: 'Continue shopping', remove: 'Remove', clear: 'Clear bag' },
    home: { eyebrow: 'New drop / Fall 2026', titleA: 'Dress simple,', titleB: 'be impossible to miss.', description: 'Clothes made for movement, staying out late and building your own uniform. Designed in Iran, ready for anywhere.', pieces: 'Limited pieces', models: 'Active styles', shipping: 'Fast shipping', categories: 'Shop by category', categoryHint: 'Your next everyday uniform is here.', bestsellers: 'The design team picks', featured: 'Best sellers', featuredHint: 'The pieces you loved most this week.', manifesto: 'Clothes should look like your life.', manifestoHint: 'Baran is built from easy shapes, honest fabrics and small details — so you can show up simpler, sharper and more free.', join: 'Stay in the loop', joinHint: 'Get the next drop in your inbox.' },
    shop: { title: 'The shop', subtitle: 'Pieces that were never meant to blend in.', all: 'All pieces', new: 'New in', sale: 'On sale', search: 'Search products...', sort: 'Sort by', featured: 'Baran picks', newest: 'Newest', lowToHigh: 'Price: low to high', highToLow: 'Price: high to low', empty: 'No pieces found for this filter.' },
    product: { available: 'In stock', unavailable: 'Out of stock', size: 'Size', color: 'Color', material: 'Material', description: 'About the piece', shipping: 'Free shipping over $50', returns: 'Easy 7-day exchanges', related: 'You may also like', reviews: 'Reviews', stock: 'in stock' },
    cart: { title: 'Your bag', empty: 'Your bag is waiting.', emptyHint: 'Pick a piece and start building your everyday uniform.', summary: 'Order summary', subtotal: 'Subtotal', shipping: 'Shipping', free: 'Free', total: 'Total', loginHint: 'Sign in to continue.' },
    footer: { tagline: 'Iranian streetwear for real life.', shop: 'Shop', account: 'Account', newsletter: 'Newsletter', newsletterHint: 'Get the next drop first.', email: 'Your email', subscribe: 'Join', rights: 'All rights reserved to Baran.' },
    about: { eyebrow: 'The Baran story', title: 'Less, but better.', body: 'Baran is an independent label for people who are not looking for loud clothes — they want pieces that move with their life. Every style is made with an easy shape, considered fabric and only the details it needs.', point1: 'Designed in Iran', point2: 'Considered fabrics', point3: 'Small, responsible runs' },
  },
} as const;

type Messages = typeof messages.fa | typeof messages.en;
type LocaleContextValue = { locale: Locale; setLocale: (locale: Locale) => void; direction: 'rtl' | 'ltr'; t: Messages };

const LocaleContext = createContext<LocaleContextValue | null>(null);

export function LocaleProvider({ children }: { children: React.ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>('fa');

  useEffect(() => {
    const stored = window.localStorage.getItem('baran-locale');
    if (stored === 'fa' || stored === 'en') setLocaleState(stored);
  }, []);

  useEffect(() => {
    document.documentElement.lang = locale;
    document.documentElement.dir = locale === 'fa' ? 'rtl' : 'ltr';
    window.localStorage.setItem('baran-locale', locale);
  }, [locale]);

  const value = useMemo(() => ({
    locale,
    setLocale: (nextLocale: Locale) => setLocaleState(nextLocale),
    direction: locale === 'fa' ? 'rtl' as const : 'ltr' as const,
    t: messages[locale],
  }), [locale]);

  return <LocaleContext.Provider value={value}>{children}</LocaleContext.Provider>;
}

export function useLocale() {
  const context = useContext(LocaleContext);
  if (!context) throw new Error('useLocale must be used inside LocaleProvider');
  return context;
}
