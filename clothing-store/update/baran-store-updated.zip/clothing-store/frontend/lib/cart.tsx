'use client';
/* eslint-disable react-hooks/set-state-in-effect */

import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import type { Product } from './catalog';

type CartItem = { product: Product; quantity: number; size: string; color: string };
type CartContextValue = {
  items: CartItem[];
  count: number;
  addItem: (product: Product, options?: { size?: string; color?: string }) => void;
  removeItem: (productId: number, size: string, color: string) => void;
  updateQuantity: (productId: number, size: string, color: string, quantity: number) => void;
  clear: () => void;
};

const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);

  useEffect(() => {
    const saved = window.localStorage.getItem('baran-cart');
    if (saved) {
      try { setItems(JSON.parse(saved)); } catch { window.localStorage.removeItem('baran-cart'); }
    }
  }, []);

  useEffect(() => {
    window.localStorage.setItem('baran-cart', JSON.stringify(items));
  }, [items]);

  const value = useMemo<CartContextValue>(() => ({
    items,
    count: items.reduce((total, item) => total + item.quantity, 0),
    addItem: (product, options = {}) => {
      const size = options.size ?? product.attributes.size[0];
      const color = options.color ?? product.attributes.color[0].slug;
      setItems((current) => {
        const existing = current.find((item) => item.product.id === product.id && item.size === size && item.color === color);
        if (existing) return current.map((item) => item === existing ? { ...item, quantity: Math.min(item.quantity + 1, product.stock) } : item);
        return [...current, { product, quantity: 1, size, color }];
      });
    },
    removeItem: (productId, size, color) => setItems((current) => current.filter((item) => !(item.product.id === productId && item.size === size && item.color === color))),
    updateQuantity: (productId, size, color, quantity) => setItems((current) => current.map((item) => item.product.id === productId && item.size === size && item.color === color ? { ...item, quantity: Math.max(1, Math.min(quantity, item.product.stock)) } : item)),
    clear: () => setItems([]),
  }), [items]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) throw new Error('useCart must be used inside CartProvider');
  return context;
}
