import { api } from './api';
import type { ApiProduct, Locale } from '@/lib/catalog';

export async function getCatalogProducts(locale: Locale) {
  const response = await api.get<{ data: ApiProduct[] }>('/catalog/products', { params: { locale, per_page: 48 } });
  return response.data.data;
}
