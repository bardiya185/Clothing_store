'use client';

import Image from 'next/image';
import Link from 'next/link';
import { ArrowLeft, Check, Minus, Plus, ShieldCheck, Truck } from 'lucide-react';
import { useState } from 'react';
import { toast } from 'sonner';
import { formatPrice, getProduct, products } from '@/lib/catalog';
import { useLocale } from '@/lib/i18n';
import { useCart } from '@/lib/cart';
import ProductCard from './ProductCard';

export default function ProductDetail({ slug }: { slug: string }) {
  const { locale, t } = useLocale();
  const { addItem } = useCart();
  const product = getProduct(slug);
  const [size, setSize] = useState(product?.attributes.size[1] ?? product?.attributes.size[0] ?? 'M');
  const [color, setColor] = useState(product?.attributes.color[0].slug ?? 'black');
  const [quantity, setQuantity] = useState(1);

  if (!product) return <div className="mx-auto max-w-[1440px] px-5 py-24"><Link href="/shop" className="font-bold text-accent">{t.actions.back}</Link></div>;

  const name = product.name[locale];
  const colorOption = product.attributes.color.find((item) => item.slug === color);
  const addToBag = () => { for (let index = 0; index < quantity; index += 1) addItem(product, { size, color }); toast.success(t.actions.added, { description: name }); };
  const related = productsForRelated(product.id);

  return <div className="mx-auto max-w-[1440px] px-5 py-8 md:px-10 md:py-14"><Link href="/shop" className="mb-8 inline-flex items-center gap-2 text-sm font-bold text-muted-foreground transition hover:text-accent"><ArrowLeft size={16} />{t.actions.back}</Link><div className="grid gap-10 lg:grid-cols-[1.08fr_.92fr] lg:gap-16"><div className="grid grid-cols-2 gap-3"><div className="relative col-span-2 aspect-[1.18] overflow-hidden rounded-[1.5rem] bg-[#e8e5dc] dark:bg-zinc-800"><Image src={product.image} alt={name} fill priority sizes="(max-width: 1024px) 100vw, 55vw" className="object-cover" /></div><div className="relative aspect-square overflow-hidden rounded-[1.2rem] bg-[#e8e5dc] dark:bg-zinc-800"><Image src={product.image} alt={name} fill sizes="30vw" className="object-cover" /></div><div className="relative aspect-square overflow-hidden rounded-[1.2rem] bg-[#e8e5dc] dark:bg-zinc-800"><div className="flex h-full items-center justify-center bg-[#252522] text-center text-white"><span className="text-xs font-bold uppercase tracking-[.25em] text-accent">BARAN<br />ESSENTIALS</span></div></div></div><div className="lg:pt-4"><div className="mb-4 flex items-center gap-2 text-xs font-bold uppercase tracking-[.18em] text-accent"><span>{product.category[locale]}</span><span className="text-border">/</span><span>{product.sku}</span></div><h1 className="display-heading max-w-xl text-5xl font-black md:text-7xl">{name}</h1><div className="mt-6 flex items-center gap-4"><span className="text-2xl font-black text-accent ltr-number">{formatPrice(product, locale)}</span>{product.compareToman && <span className="text-sm text-muted-foreground line-through ltr-number">{locale === 'fa' ? `${product.compareToman.toLocaleString('fa-IR')} تومان` : `$${product.compareUsd}`}</span>}<span className="text-sm text-amber-500">★ {product.rating} <span className="text-muted-foreground">({product.reviews})</span></span></div><p className="mt-7 max-w-xl text-base leading-8 text-muted-foreground">{product.description[locale]}</p><div className="my-8 border-y border-border py-6"><div className="mb-5 flex items-center justify-between"><span className="text-sm font-bold">{t.product.size}</span><button className="text-xs text-muted-foreground underline">{locale === 'fa' ? 'راهنمای سایز' : 'Size guide'}</button></div><div className="flex flex-wrap gap-2">{product.attributes.size.map((item) => <button key={item} onClick={() => setSize(item)} className={`min-w-14 rounded-full border px-4 py-2.5 text-sm font-bold transition ${size === item ? 'border-foreground bg-foreground text-background' : 'border-border hover:border-foreground'}`}>{item}</button>)}</div><div className="mb-5 mt-7 text-sm font-bold">{t.product.color}: <span className="font-normal text-muted-foreground">{colorOption?.[locale]}</span></div><div className="flex gap-3">{product.attributes.color.map((item) => <button key={item.slug} onClick={() => setColor(item.slug)} aria-label={item[locale]} className={`flex h-9 w-9 items-center justify-center rounded-full border-2 transition ${color === item.slug ? 'border-accent' : 'border-transparent'}`}><span className="h-7 w-7 rounded-full border border-black/10" style={{ backgroundColor: item.hex }} /></button>)}</div></div><div className="flex gap-3"><div className="flex items-center rounded-full border border-border"><button onClick={() => setQuantity((value) => Math.max(1, value - 1))} className="p-3" aria-label="Decrease"><Minus size={16} /></button><span className="w-8 text-center text-sm font-bold">{quantity}</span><button onClick={() => setQuantity((value) => Math.min(product.stock, value + 1))} className="p-3" aria-label="Increase"><Plus size={16} /></button></div><button onClick={addToBag} className="flex flex-1 items-center justify-center gap-2 rounded-full bg-foreground px-6 py-3.5 text-sm font-bold text-background transition hover:bg-accent hover:text-white">{t.actions.add}<ArrowLeft size={16} /></button></div><div className="mt-8 grid gap-4 border-t border-border pt-6 text-sm"><div className="flex items-center gap-3"><Truck size={18} className="text-accent" /><span>{t.product.shipping}</span></div><div className="flex items-center gap-3"><ShieldCheck size={18} className="text-accent" /><span>{t.product.returns}</span></div><div className="flex items-center gap-3"><Check size={18} className="text-accent" /><span>{product.stock} {t.product.stock}</span></div></div></div></div><section className="mt-24 border-t border-border pt-12"><h2 className="mb-8 text-3xl font-black">{t.product.related}</h2><div className="grid grid-cols-2 gap-4 md:grid-cols-3">{related.map((item) => <ProductCard key={item.id} product={item} />)}</div></section></div>;
}

function productsForRelated(currentId: number) {
  return products.filter((item) => item.id !== currentId).slice(0, 3);
}

