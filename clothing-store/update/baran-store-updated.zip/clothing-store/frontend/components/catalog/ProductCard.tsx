'use client';

import Image from 'next/image';
import Link from 'next/link';
import { Heart, Plus } from 'lucide-react';
import { toast } from 'sonner';
import type { Product } from '@/lib/catalog';
import { formatPrice } from '@/lib/catalog';
import { useLocale } from '@/lib/i18n';
import { useCart } from '@/lib/cart';

export default function ProductCard({ product, priority = false }: { product: Product; priority?: boolean }) {
  const { locale, t } = useLocale();
  const { addItem } = useCart();
  const name = product.name[locale];

  const handleAdd = () => {
    addItem(product);
    toast.success(t.actions.added, { description: name });
  };

  return (
    <article className="group min-w-0">
      <div className="relative mb-4 aspect-[4/5] overflow-hidden rounded-[1.6rem] bg-[#e8e5dc] dark:bg-zinc-800">
        <Link href={`/product/${product.slug}`} aria-label={name} className="absolute inset-0 z-[1]">
          <Image src={product.image} alt={name} fill priority={priority} sizes="(max-width: 768px) 50vw, 25vw" className="object-cover transition duration-700 group-hover:scale-105" />
        </Link>
        <div className="hero-gradient pointer-events-none absolute inset-0 z-[2] opacity-40 transition duration-500 group-hover:opacity-70" />
        <div className="absolute left-4 right-4 top-4 z-[3] flex items-start justify-between">
          <div className="flex gap-2">
            {product.isNew && <span className="rounded-full bg-white/90 px-3 py-1 text-[11px] font-bold text-black backdrop-blur dark:bg-black/70 dark:text-white">{locale === 'fa' ? 'جدید' : 'New'}</span>}
            {product.compareToman && <span className="rounded-full bg-accent px-3 py-1 text-[11px] font-bold text-white">{locale === 'fa' ? 'پیشنهاد ویژه' : 'Sale'}</span>}
          </div>
          <button aria-label={locale === 'fa' ? 'افزودن به علاقه‌مندی‌ها' : 'Add to wishlist'} className="rounded-full bg-white/90 p-2.5 text-black backdrop-blur transition hover:bg-black hover:text-white dark:bg-black/60 dark:text-white dark:hover:bg-white dark:hover:text-black">
            <Heart size={17} strokeWidth={1.8} />
          </button>
        </div>
        <button onClick={handleAdd} className="absolute bottom-4 left-4 right-4 z-[3] flex translate-y-2 items-center justify-center gap-2 rounded-full bg-white/95 py-3 text-sm font-bold text-black opacity-0 backdrop-blur transition duration-300 hover:bg-accent hover:text-white group-hover:translate-y-0 group-hover:opacity-100 dark:bg-black/90 dark:text-white">
          <Plus size={16} /> {t.actions.add}
        </button>
      </div>
      <div className="flex items-start justify-between gap-3 px-1">
        <div className="min-w-0">
          <Link href={`/product/${product.slug}`} className="block truncate text-base font-bold transition hover:text-accent">{name}</Link>
          <p className="mt-1 text-xs text-muted-foreground">{product.category[locale]}</p>
          <p className="mt-2 font-bold text-accent ltr-number">{formatPrice(product, locale)}</p>
        </div>
        <div className="flex shrink-0 items-center gap-1 pt-1 text-xs text-muted-foreground">
          <span className="text-amber-500">★</span>{product.rating}
        </div>
      </div>
    </article>
  );
}
