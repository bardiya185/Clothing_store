'use client';

import { Search, SlidersHorizontal, X } from 'lucide-react';
import { useMemo, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { useQuery } from '@tanstack/react-query';
import { categories, mapApiProduct, products } from '@/lib/catalog';
import { useLocale } from '@/lib/i18n';
import ProductCard from './ProductCard';
import { getCatalogProducts } from '@/services/catalog.service';

export default function ShopView({ initialGender }: { initialGender?: 'men' | 'women' }) {
  const { locale, t } = useLocale();
  const searchParams = useSearchParams();
  const [query, setQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'new' | 'sale'>('all');
  const [sort, setSort] = useState('featured');
  const [category, setCategory] = useState(searchParams.get('category') ?? 'all');
  const [mobileFilters, setMobileFilters] = useState(false);
  const { data: apiProducts } = useQuery({
    queryKey: ['catalog-products', locale],
    queryFn: () => getCatalogProducts(locale),
    enabled: Boolean(process.env.NEXT_PUBLIC_API_URL),
    retry: 0,
  });
  const catalogProducts = apiProducts?.length ? apiProducts.map((item) => mapApiProduct(item, locale)) : products;

  const filtered = useMemo(() => {
    const result = catalogProducts.filter((product) => {
      const text = `${product.name.fa} ${product.name.en} ${product.category.fa} ${product.category.en}`.toLowerCase();
      return (category === 'all' || product.category.slug === category) && (!initialGender || product.gender === initialGender || product.gender === 'unisex') && (activeTab !== 'new' || product.isNew) && (activeTab !== 'sale' || product.compareToman) && (!query.trim() || text.includes(query.toLowerCase().trim()));
    });
    return [...result].sort((a, b) => sort === 'low' ? a.priceToman - b.priceToman : sort === 'high' ? b.priceToman - a.priceToman : sort === 'newest' ? Number(b.isNew) - Number(a.isNew) : Number(b.isFeatured) - Number(a.isFeatured));
  }, [activeTab, category, catalogProducts, initialGender, query, sort]);

  const heading = initialGender === 'men' ? t.nav.men : initialGender === 'women' ? t.nav.women : t.shop.title;

  return (
    <div className="mx-auto max-w-[1440px] px-5 py-12 md:px-10 md:py-20">
      <div className="mb-12 flex flex-col justify-between gap-7 border-b border-border pb-10 md:flex-row md:items-end"><div><p className="mb-3 text-xs font-bold uppercase tracking-[.2em] text-accent">BARAN / COLLECTION</p><h1 className="display-heading text-6xl font-black md:text-8xl">{heading}</h1><p className="mt-5 text-sm text-muted-foreground">{t.shop.subtitle}</p></div><div className="rounded-full border border-border px-4 py-2 text-sm text-muted-foreground">{filtered.length} {locale === 'fa' ? 'محصول' : 'pieces'}</div></div>
      <div className="mb-8 flex flex-col gap-4 md:flex-row md:items-center md:justify-between"><div className="flex gap-2 overflow-x-auto no-scrollbar"><button onClick={() => setActiveTab('all')} className={`shrink-0 rounded-full px-5 py-2.5 text-sm font-bold transition ${activeTab === 'all' ? 'bg-foreground text-background' : 'border border-border text-muted-foreground hover:text-foreground'}`}>{t.shop.all}</button><button onClick={() => setActiveTab('new')} className={`shrink-0 rounded-full px-5 py-2.5 text-sm font-bold transition ${activeTab === 'new' ? 'bg-foreground text-background' : 'border border-border text-muted-foreground hover:text-foreground'}`}>{t.shop.new}</button><button onClick={() => setActiveTab('sale')} className={`shrink-0 rounded-full px-5 py-2.5 text-sm font-bold transition ${activeTab === 'sale' ? 'bg-foreground text-background' : 'border border-border text-muted-foreground hover:text-foreground'}`}>{t.shop.sale}</button></div><div className="flex gap-2"><label className="flex min-w-0 flex-1 items-center gap-2 rounded-full border border-border bg-card px-4 py-2.5 md:w-64 md:flex-none"><Search size={17} className="shrink-0 text-muted-foreground" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={t.shop.search} className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground" />{query && <button onClick={() => setQuery('')} aria-label="Clear"><X size={15} /></button>}</label><button onClick={() => setMobileFilters((open) => !open)} className="rounded-full border border-border p-3 md:hidden" aria-label="Filters"><SlidersHorizontal size={18} /></button><select value={sort} onChange={(event) => setSort(event.target.value)} className="hidden rounded-full border border-border bg-transparent px-4 text-sm outline-none md:block"><option value="featured">{t.shop.featured}</option><option value="newest">{t.shop.newest}</option><option value="low">{t.shop.lowToHigh}</option><option value="high">{t.shop.highToLow}</option></select></div></div>
      <div className={`${mobileFilters ? 'flex' : 'hidden'} mb-6 flex-wrap gap-2 md:flex`}><button onClick={() => setCategory('all')} className={`rounded-full px-4 py-2 text-xs font-bold ${category === 'all' ? 'bg-accent text-white' : 'border border-border text-muted-foreground'}`}>{t.shop.all}</button>{categories.map((item) => <button key={item.slug} onClick={() => setCategory(item.slug)} className={`rounded-full px-4 py-2 text-xs font-bold ${category === item.slug ? 'bg-accent text-white' : 'border border-border text-muted-foreground'}`}>{item[locale]}</button>)}</div>
      {filtered.length ? <div className="grid grid-cols-2 gap-x-4 gap-y-10 md:grid-cols-3 lg:grid-cols-4 md:gap-x-6 md:gap-y-14">{filtered.map((product, index) => <ProductCard key={product.id} product={product} priority={index < 2} />)}</div> : <div className="flex min-h-80 flex-col items-center justify-center rounded-[1.5rem] border border-dashed border-border text-center"><p className="text-2xl font-bold">{t.shop.empty}</p><button onClick={() => { setQuery(''); setCategory('all'); setActiveTab('all'); }} className="mt-5 rounded-full bg-foreground px-5 py-2.5 text-sm font-bold text-background">{locale === 'fa' ? 'پاک کردن فیلترها' : 'Clear filters'}</button></div>}
    </div>
  );
}
