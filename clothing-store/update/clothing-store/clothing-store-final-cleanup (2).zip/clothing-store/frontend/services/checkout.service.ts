import { api } from "./api";
import type { Locale } from "@/lib/product";

export type CheckoutPayload = {
  locale: Locale;
  customer_name: string;
  customer_phone: string;
  customer_address: string;
  postal_code: string;
  card_number: string;
  items: {
    product_id: number;
    variant_id: number;
    quantity: number;
    size: string;
    color: string;
  }[];
};

export type Receipt = {
  order_number: string;
  payment_reference: string;
  paid_at: string;
  currency: string;
  total_toman: number;
  total_usd: number;
  items: {
    name: string;
    sku: string;
    quantity: number;
    unit_price_toman: number;
    unit_price_usd: number;
    total_toman: number;
    total_usd: number;
    options: { size?: string | null; color?: string | null };
  }[];
};

export async function fakePay(payload: CheckoutPayload) {
  const response = await api.post<{ message: string; data: Receipt }>(
    "/checkout/fake-pay",
    payload,
    { params: { locale: payload.locale } },
  );
  return response.data;
}
