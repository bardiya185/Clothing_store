"use client";

import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowLeft,
  Check,
  CreditCard,
  Loader2,
  MapPin,
  Phone,
  Printer,
  UserRound,
} from "lucide-react";
import { useState } from "react";
import { formatAmount } from "@/lib/product";
import { getApiErrorMessage } from "@/lib/api-error";
import { useLocale } from "@/hooks/useLocale";
import { useCart } from "@/hooks/useCart";
import { fakePay, type Receipt } from "@/services/checkout.service";

const initialForm = {
  customer_name: "",
  customer_phone: "",
  customer_address: "",
  postal_code: "",
  card_number: "6037991812345678",
};

function ReceiptPrinter({ receipt }: { receipt: Receipt }) {
  const { locale, t } = useLocale();

  return (
    <motion.section
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="relative mx-auto max-w-2xl overflow-hidden rounded-[2rem] border border-border bg-card shadow-xl shadow-black/5"
    >
      <div className="relative overflow-hidden bg-[#24231f] px-6 py-8 text-white sm:px-10">
        <motion.div
          initial={{ y: -80, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.25, duration: 0.8, ease: "easeOut" }}
          className="relative z-10 flex items-center justify-between"
        >
          <div>
            <p className="text-xs font-bold uppercase tracking-[.22em] text-accent">
              BARAN / RECEIPT
            </p>
            <h1 className="mt-3 text-3xl font-black">{t.checkout.receipt}</h1>
            <p className="mt-2 text-sm text-white/60">
              {t.checkout.receiptHint}
            </p>
          </div>
          <motion.div
            initial={{ rotate: -25, scale: 0.7 }}
            animate={{ rotate: 0, scale: 1 }}
            transition={{ delay: 0.7, type: "spring" }}
            className="flex h-14 w-14 items-center justify-center rounded-2xl bg-accent text-white"
          >
            <Check size={28} strokeWidth={3} />
          </motion.div>
        </motion.div>
        <div className="absolute -bottom-16 -left-8 h-40 w-40 rounded-full border-[26px] border-accent/30" />
      </div>
      <motion.div
        initial={{ height: 0, opacity: 0 }}
        animate={{ height: "auto", opacity: 1 }}
        transition={{ delay: 0.45, duration: 0.75 }}
        className="overflow-hidden"
      >
        <div className="relative p-6 sm:p-10">
          <motion.div
            initial={{ scaleY: 0 }}
            animate={{ scaleY: 1 }}
            transition={{ delay: 0.65, duration: 0.8, ease: "easeOut" }}
            style={{ transformOrigin: "top" }}
            className="absolute inset-x-6 top-0 border-t-2 border-dashed border-accent/50 sm:inset-x-10"
          />
          <div className="grid gap-3 border-b border-border pb-6 text-sm sm:grid-cols-3">
            <div>
              <span className="block text-xs text-muted-foreground">
                {t.checkout.orderNumber}
              </span>
              <strong className="mt-1 block ltr-number">
                {receipt.order_number}
              </strong>
            </div>
            <div>
              <span className="block text-xs text-muted-foreground">
                {t.checkout.reference}
              </span>
              <strong className="mt-1 block ltr-number">
                {receipt.payment_reference}
              </strong>
            </div>
            <div>
              <span className="block text-xs text-muted-foreground">
                {t.checkout.paidAt}
              </span>
              <strong className="mt-1 block ltr-number">
                {new Intl.DateTimeFormat(locale === "fa" ? "fa-IR" : "en-US", {
                  dateStyle: "medium",
                  timeStyle: "short",
                }).format(new Date(receipt.paid_at))}
              </strong>
            </div>
          </div>
          <div className="divide-y divide-border">
            {receipt.items.map((item, index) => (
              <motion.div
                key={`${item.sku}-${index}`}
                initial={{ opacity: 0, x: locale === "fa" ? 18 : -18 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.9 + index * 0.12 }}
                className="flex items-center justify-between gap-4 py-4"
              >
                <div className="min-w-0">
                  <p className="truncate font-bold">{item.name}</p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {item.sku} · {item.quantity} × {item.options?.size || "—"}
                  </p>
                </div>
                <span className="shrink-0 font-bold text-accent ltr-number">
                  {formatAmount(item.total_toman, item.total_usd, locale)}
                </span>
              </motion.div>
            ))}
          </div>
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2 }}
            className="mt-5 flex items-center justify-between border-t-2 border-foreground pt-5 text-lg"
          >
            <span className="font-black">
              {locale === "fa" ? "مبلغ پرداخت‌شده" : "Paid total"}
            </span>
            <span className="font-black text-accent ltr-number">
              {formatAmount(receipt.total_toman, receipt.total_usd, locale)}
            </span>
          </motion.div>
          <div className="mt-8 flex items-center justify-center gap-2 text-xs font-bold text-emerald-600">
            <Printer size={15} />
            {t.checkout.print}
          </div>
        </div>
      </motion.div>
    </motion.section>
  );
}

export default function CheckoutPage() {
  const { locale, t } = useLocale();
  const { items, clear } = useCart();
  const [form, setForm] = useState(initialForm);
  const [receipt, setReceipt] = useState<Receipt | null>(null);
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState("");

  const tomanTotal = items.reduce(
    (total, item) => total + item.product.priceToman * item.quantity,
    0,
  );
  const usdTotal = items.reduce(
    (total, item) => total + item.product.priceUsd * item.quantity,
    0,
  );

  const updateField = (field: keyof typeof initialForm, value: string) => {
    setForm((current) => ({ ...current, [field]: value }));
    setError("");
  };

  const submitPayment = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setProcessing(true);
    setError("");
    try {
      const response = await fakePay({
        locale,
        ...form,
        items: items.map((item) => ({
          product_id: item.product.id,
          variant_id: item.variantId,
          quantity: item.quantity,
          size: item.size,
          color: item.color,
        })),
      });
      setReceipt(response.data);
      clear();
    } catch (requestError) {
      setError(
        getApiErrorMessage(
          requestError,
          locale === "fa"
            ? "پرداخت انجام نشد. دوباره تلاش کن."
            : "Payment failed. Please try again.",
        ),
      );
    } finally {
      setProcessing(false);
    }
  };

  if (receipt) {
    return (
      <div className="mx-auto max-w-[1440px] px-4 py-10 sm:px-5 md:px-10 md:py-20">
        <div className="mb-8 text-center">
          <p className="mb-3 text-xs font-bold uppercase tracking-[.2em] text-accent">
            BARAN / DONE
          </p>
          <h1 className="display-heading text-5xl font-black sm:text-7xl">
            {t.checkout.receipt}
          </h1>
        </div>
        <ReceiptPrinter receipt={receipt} />
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link
            href="/shop"
            className="inline-flex items-center gap-2 rounded-full bg-foreground px-6 py-3.5 text-sm font-bold text-background transition hover:bg-accent hover:text-white"
          >
            {t.checkout.continue}
            <ArrowLeft size={16} />
          </Link>
          <Link
            href="/account"
            className="inline-flex items-center gap-2 rounded-full border border-border px-6 py-3.5 text-sm font-bold transition hover:border-accent hover:text-accent"
          >
            {locale === "fa" ? "حساب کاربری" : "My account"}
          </Link>
        </div>
      </div>
    );
  }

  if (!items.length) {
    return (
      <div className="mx-auto flex min-h-[65vh] max-w-[1440px] flex-col items-center justify-center px-5 py-20 text-center">
        <CreditCard className="mb-6 text-accent" size={42} />
        <h1 className="text-3xl font-black">{t.cart.empty}</h1>
        <Link
          href="/shop"
          className="mt-7 inline-flex items-center gap-2 rounded-full bg-foreground px-6 py-3.5 text-sm font-bold text-background"
        >
          {t.actions.continue}
          <ArrowLeft size={16} />
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-[1440px] px-4 py-8 sm:px-5 md:px-10 md:py-16">
      <Link
        href="/cart"
        className="mb-8 inline-flex items-center gap-2 text-sm font-bold text-muted-foreground transition hover:text-accent"
      >
        <ArrowLeft size={16} />
        {t.checkout.backToBag}
      </Link>
      <div className="mb-10">
        <p className="mb-3 text-xs font-bold uppercase tracking-[.2em] text-accent">
          BARAN / CHECKOUT
        </p>
        <h1 className="display-heading text-5xl font-black sm:text-7xl">
          {t.checkout.title}
        </h1>
        <p className="mt-4 max-w-xl text-sm leading-7 text-muted-foreground">
          {t.checkout.subtitle}
        </p>
      </div>
      <div className="grid gap-8 lg:grid-cols-[1fr_360px] lg:items-start">
        <form
          onSubmit={submitPayment}
          className="rounded-[1.75rem] border border-border bg-card p-5 shadow-sm sm:p-8"
        >
          <div className="grid gap-5 sm:grid-cols-2">
            <label className="sm:col-span-2">
              <span className="mb-2 flex items-center gap-2 text-sm font-bold">
                <UserRound size={16} className="text-accent" />
                {t.checkout.customerName}
              </span>
              <input
                required
                value={form.customer_name}
                onChange={(event) =>
                  updateField("customer_name", event.target.value)
                }
                className="w-full rounded-2xl border border-border bg-background px-4 py-3.5 outline-none transition focus:border-accent"
              />
            </label>
            <label>
              <span className="mb-2 flex items-center gap-2 text-sm font-bold">
                <Phone size={16} className="text-accent" />
                {t.checkout.phone}
              </span>
              <input
                required
                inputMode="tel"
                value={form.customer_phone}
                onChange={(event) =>
                  updateField("customer_phone", event.target.value)
                }
                className="w-full rounded-2xl border border-border bg-background px-4 py-3.5 outline-none transition focus:border-accent"
              />
            </label>
            <label>
              <span className="mb-2 block text-sm font-bold">
                {t.checkout.postalCode}
              </span>
              <input
                required
                inputMode="numeric"
                value={form.postal_code}
                onChange={(event) =>
                  updateField("postal_code", event.target.value)
                }
                className="w-full rounded-2xl border border-border bg-background px-4 py-3.5 outline-none transition focus:border-accent"
              />
            </label>
            <label className="sm:col-span-2">
              <span className="mb-2 flex items-center gap-2 text-sm font-bold">
                <MapPin size={16} className="text-accent" />
                {t.checkout.address}
              </span>
              <textarea
                required
                rows={3}
                value={form.customer_address}
                onChange={(event) =>
                  updateField("customer_address", event.target.value)
                }
                className="w-full resize-none rounded-2xl border border-border bg-background px-4 py-3.5 outline-none transition focus:border-accent"
              />
            </label>
            <label className="sm:col-span-2">
              <span className="mb-2 flex items-center gap-2 text-sm font-bold">
                <CreditCard size={16} className="text-accent" />
                {t.checkout.cardNumber}
              </span>
              <input
                required
                minLength={16}
                maxLength={16}
                pattern="[0-9]{16}"
                inputMode="numeric"
                value={form.card_number}
                onChange={(event) =>
                  updateField(
                    "card_number",
                    event.target.value.replace(/\D/g, "").slice(0, 16),
                  )
                }
                className="w-full rounded-2xl border border-border bg-background px-4 py-3.5 tracking-[.2em] outline-none transition focus:border-accent"
              />
              <span className="mt-2 block text-xs text-muted-foreground">
                {t.checkout.cardHint}
              </span>
            </label>
          </div>
          {error && (
            <div className="mt-5 rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm font-bold text-rose-700 dark:border-rose-900 dark:bg-rose-950/30 dark:text-rose-300">
              {error}
            </div>
          )}
          <button
            type="submit"
            disabled={processing}
            className="mt-7 flex min-h-14 w-full items-center justify-center gap-2 rounded-full bg-foreground px-6 py-4 text-sm font-bold text-background transition hover:bg-accent hover:text-white disabled:cursor-wait disabled:opacity-60"
          >
            {processing ? (
              <Loader2 size={18} className="animate-spin" />
            ) : (
              <CreditCard size={18} />
            )}
            {processing ? t.checkout.processing : t.checkout.pay}
          </button>
          <p className="mt-4 text-center text-xs text-muted-foreground">
            {t.checkout.secure}
          </p>
        </form>
        <aside className="rounded-[1.75rem] bg-[#24231f] p-6 text-white shadow-xl sm:p-7 lg:sticky lg:top-28">
          <h2 className="text-xl font-black">{t.cart.summary}</h2>
          <div className="mt-6 space-y-4">
            {items.map((item) => (
              <div
                key={`${item.product.id}-${item.variantId}`}
                className="flex justify-between gap-3 text-sm"
              >
                <span className="min-w-0 truncate text-white/65">
                  {item.product.name} × {item.quantity}
                </span>
                <span className="shrink-0 font-bold ltr-number">
                  {formatAmount(
                    item.product.priceToman * item.quantity,
                    item.product.priceUsd * item.quantity,
                    locale,
                  )}
                </span>
              </div>
            ))}
          </div>
          <div className="mt-7 flex justify-between border-t border-white/15 pt-5 text-lg">
            <span className="font-black">{t.cart.total}</span>
            <span className="font-black text-[#ff8a61] ltr-number">
              {formatAmount(tomanTotal, usdTotal, locale)}
            </span>
          </div>
        </aside>
      </div>
      <AnimatePresence>
        {processing && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="pointer-events-none fixed inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-[2px]"
          >
            <motion.div
              initial={{ scale: 0.8, rotate: -5 }}
              animate={{ scale: 1, rotate: 0 }}
              className="rounded-3xl bg-card p-7 text-center shadow-2xl"
            >
              <Printer
                className="mx-auto mb-3 animate-pulse text-accent"
                size={34}
              />
              <p className="font-bold">{t.checkout.processing}</p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
