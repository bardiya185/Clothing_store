<?php

namespace App\Services;

use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use App\Support\LocaleManager;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class CheckoutService
{
    public function fakePay(array $payload, string $locale, ?User $user = null): Order
    {
        return DB::transaction(function () use ($payload, $locale, $user): Order {
            $subtotalToman = 0;
            $subtotalUsd = 0;
            $items = [];

            foreach ($payload['items'] as $item) {
                $product = Product::query()
                    ->whereKey($item['product_id'])
                    ->where('status', 'published')
                    ->with(['translations', 'variants'])
                    ->lockForUpdate()
                    ->first();

                if (!$product) {
                    throw ValidationException::withMessages([
                        'items' => [__('checkout.product_unavailable')],
                    ]);
                }

                $variant = $product->variants
                    ->firstWhere('id', $item['variant_id'] ?? null)
                    ?? $product->variants->firstWhere('is_default', true)
                    ?? $product->variants->firstWhere('is_active', true);

                if (!$variant || !$variant->is_active || $variant->stock < $item['quantity']) {
                    throw ValidationException::withMessages([
                        'items' => [__('checkout.stock_insufficient', ['product' => $product->slug])],
                    ]);
                }

                $nameFa = LocaleManager::translate($product->translations, 'fa') ?? $product->slug;
                $nameEn = LocaleManager::translate($product->translations, 'en') ?? $product->slug;
                $lineToman = (int) $variant->price_toman * $item['quantity'];
                $lineUsd = (float) $variant->price_usd * $item['quantity'];
                $subtotalToman += $lineToman;
                $subtotalUsd += $lineUsd;

                $variant->decrement('stock', $item['quantity']);
                $items[] = [
                    'product_id' => $product->id,
                    'variant_id' => $variant->id,
                    'sku' => $variant->sku,
                    'product_name_fa' => $nameFa,
                    'product_name_en' => $nameEn,
                    'quantity' => $item['quantity'],
                    'unit_price_toman' => (int) $variant->price_toman,
                    'unit_price_usd' => (float) $variant->price_usd,
                    'total_toman' => $lineToman,
                    'total_usd' => $lineUsd,
                    'options' => [
                        'size' => $item['size'] ?? null,
                        'color' => $item['color'] ?? null,
                    ],
                ];
            }

            $reference = 'FAKE-'.strtoupper(Str::random(10));
            $order = Order::create([
                'user_id' => $user?->id,
                'number' => 'BRN-'.now()->format('ymdHis').strtoupper(Str::random(4)),
                'status' => 'paid',
                'payment_status' => 'paid',
                'payment_reference' => $reference,
                'currency_code' => LocaleManager::currencyFor($locale),
                'subtotal_toman' => $subtotalToman,
                'subtotal_usd' => $subtotalUsd,
                'total_toman' => $subtotalToman,
                'total_usd' => $subtotalUsd,
                'customer_name' => $payload['customer_name'],
                'customer_phone' => $payload['customer_phone'],
                'customer_address' => $payload['customer_address'],
                'postal_code' => $payload['postal_code'],
                'paid_at' => now(),
            ]);

            $order->items()->createMany($items);

            return $order->load('items');
        });
    }
}
