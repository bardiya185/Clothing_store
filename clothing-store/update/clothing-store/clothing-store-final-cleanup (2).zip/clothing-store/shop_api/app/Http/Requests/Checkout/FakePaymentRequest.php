<?php

namespace App\Http\Requests\Checkout;

use Illuminate\Foundation\Http\FormRequest;

class FakePaymentRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'customer_name' => ['required', 'string', 'max:120'],
            'customer_phone' => ['required', 'string', 'max:20'],
            'customer_address' => ['required', 'string', 'max:1000'],
            'postal_code' => ['required', 'string', 'max:20'],
            'card_number' => ['required', 'digits:16'],
            'items' => ['required', 'array', 'min:1'],
            'items.*.product_id' => ['required', 'integer', 'exists:products,id'],
            'items.*.variant_id' => ['nullable', 'integer', 'exists:product_variants,id'],
            'items.*.quantity' => ['required', 'integer', 'min:1', 'max:10'],
            'items.*.size' => ['nullable', 'string', 'max:30'],
            'items.*.color' => ['nullable', 'string', 'max:40'],
        ];
    }

    public function messages(): array
    {
        return [
            'customer_name.required' => __('checkout.customer_name_required'),
            'customer_phone.required' => __('checkout.customer_phone_required'),
            'customer_address.required' => __('checkout.customer_address_required'),
            'postal_code.required' => __('checkout.postal_code_required'),
            'card_number.required' => __('checkout.card_number_required'),
            'card_number.digits' => __('checkout.card_number_digits'),
        ];
    }
}
